import React, { useState } from 'react';
import './App.css';
import MovieForm from './components/MovieForm';
import BudgetSection from './components/BudgetSection';
import MovieList from './components/MovieList';

function App() {
  const [movies, setMovies] = useState([]);
  const [budget, setBudget] = useState(40000000);
  const [additionalBudget, setAdditionalBudget] = useState(0);
  const [filter, setFilter] = useState({ movie: '', date: '' });

  const addMovie = (movie) => {
    setMovies([...movies, movie]);
    setBudget(budget - parseInt(movie.budget));
  };

  const handleAddBudget = () => {
    setBudget(budget + additionalBudget);
    setAdditionalBudget(0);
  };

  return (
    <div className="App">
      <div className="left-half">
        <MovieForm addMovie={addMovie} />
      </div>
      <div className="right-half">
        <BudgetSection
          budget={budget}
          additionalBudget={additionalBudget}
          setAdditionalBudget={setAdditionalBudget}
          handleAddBudget={handleAddBudget}
        />
        <MovieList movies={movies} filter={filter} setFilter={setFilter} />
      </div>
    </div>
  );
}

export default App;
