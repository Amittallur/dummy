import React from 'react';
import './MovieList.css';

function MovieList({ movies, filter, setFilter }) {
  const filteredMovies = movies.filter(
    (movie) =>
      movie.name.toLowerCase().includes(filter.movie.toLowerCase()) &&
      movie.date.includes(filter.date)
  );

  const handleResetFilter = () => {
    setFilter({ movie: '', date: '' });
  };

  return (
    <div className="movie-list">
      <h2>Movie List</h2>
      <div className="filter-box">
        <input
          type="text"
          placeholder="Filter by Movie Name"
          value={filter.movie}
          onChange={(e) => setFilter({ ...filter, movie: e.target.value })}
        />
        <input
          type="date"
          placeholder="Filter by Date"
          value={filter.date}
          onChange={(e) => setFilter({ ...filter, date: e.target.value })}
        />
        <button onClick={handleResetFilter}>Reset Filters</button>
      </div>
      <ul>
        {filteredMovies.map((movie, index) => (
          <li key={index}>
            {movie.name} - Budget: {movie.budget} - Date: {movie.date}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default MovieList;
