import React, { useState } from 'react';
import './MovieForm.css';

function MovieForm({ addMovie }) {
  const [movieName, setMovieName] = useState('');
  const [movieBudget, setMovieBudget] = useState('');
  const [movieDate, setMovieDate] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (movieName && movieBudget && movieDate) {
      const newMovie = {
        name: movieName,
        budget: movieBudget,
        date: movieDate,
      };
      addMovie(newMovie);
      setMovieName('');
      setMovieBudget('');
      setMovieDate('');
    }
  };

  return (
    <div className="movie-form">
      <h2>New Movie Form</h2>
      <form onSubmit={handleSubmit}>
        <label>
          Movie Name:
          <input
            type="text"
            value={movieName}
            onChange={(e) => setMovieName(e.target.value)}
          />
        </label>
        <label>
          Budget:
          <input
            type="number"
            value={movieBudget}
            onChange={(e) => setMovieBudget(e.target.value)}
          />
        </label>
        <label>
          Date:
          <input
            type="date"
            value={movieDate}
            onChange={(e) => setMovieDate(e.target.value)}
          />
        </label>
        <button type="submit">Submit</button>
      </form>
    </div>
  );
}

export default MovieForm;
