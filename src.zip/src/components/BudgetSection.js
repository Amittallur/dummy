import React from 'react';
import './BudgetSection.css';

function BudgetSection({ budget, additionalBudget, setAdditionalBudget, handleAddBudget }) {
  return (
    <div className="budget-section">
      <h2>Budget Section</h2>
      <p>Total Budget: 4 Crore</p>
      <p>Available Budget: {budget}</p>
      <div>
        <input
          type="number"
          value={additionalBudget}
          onChange={(e) => setAdditionalBudget(Number(e.target.value))}
        />
        <button onClick={handleAddBudget}>Add Budget</button>
      </div>
    </div>
  );
}

export default BudgetSection;
